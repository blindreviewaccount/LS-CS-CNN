

%% Init:
    close all
    clc
    clear

    close(findall(groot, "Type", "figure"));
    path(pathdef);
    addpath( genpath( 'Source' ) )    

%% Compression Settings
    compressionFactorReal = 30;    
    numCompressionEmbeddings = 2;
    numAugmentations = 10;

%% File and Folder settings:

    folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Source Data\train_compression_wav';
    folderSavePreprocessedBase =  'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\';

    % folderTrain = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\train_compression_wav\';
    % folderSavePreprocessedBase =  'E:\Data Deeplearning\20240502 - Lung Sound Competition\Preprocessed Data\';
    % 

    folderSavePreprocessed = strcat( folderSavePreprocessedBase, '/Preprocessed_RS_NE', num2str(numCompressionEmbeddings), '_CR', num2str(compressionFactorReal), '/' );

    mkdir( folderSavePreprocessed );

%% Some major settings:
    % What is the samplerate of the raw audio
    fsAudio = 8000;

    % What do we want to give to the CNN as input size
    inputSizeAudioData = 34976;
    % What do we want to give to the CNN as Output size
    OutputSizeAudioData = inputSizeAudioData*4;

%% Some augmentation settings
    
    maxLeadingZeroes = 3000;
    


   

%% Augmentation and preprocessing loop
    % Load all the files
    filesTrain = dir( strcat( folderTrain, '/*.wav' ) );
    numAudioFiles = length( filesTrain );

    % Some calculations on the compression settings:
    compressionFactorTime = numCompressionEmbeddings*compressionFactorReal;
    numTimeSamplesInSingleCompression = round( OutputSizeAudioData / compressionFactorTime ); 

    % Prepare the random sampling method. We will make a set of [numEmbeddings] random sequences of time samples, which are each numTimeSamplesInSingleCompression long.
    
    % Preallocate some storage
    allSampleIndexes = repmat( (1 : OutputSizeAudioData)', 1, numCompressionEmbeddings );
   
    % For every embedding, make a random permutation of all the possible
    % sample indexes
    for cntEmbedding = 1 : numCompressionEmbeddings
        allSampleIndexes( :, cntEmbedding ) = randperm( OutputSizeAudioData );
    end
    
    % Truncate to the numTimeSamplesInSingleCompression length, and then
    % sort that truncated list. This is now the index list of all the
    % random samples that each of the signals undergoes for each embedding.
    % This is the same for every audio signal.
    allSampleIndexesEmbeddingSize = allSampleIndexes( 1 : numTimeSamplesInSingleCompression, : );
    allSampleIndexesEmbeddingSize = sort(allSampleIndexesEmbeddingSize, 1 );
    
    % Make a sample times linear vector of the size that we want to feed
    % into the CNN. In this case, it is the inputSizeAudioData (34976 is
    % what we chose for the competition). We need this to "resample" the
    % random sampled signals later on.
    sampleTimesLinear = linspace( 1, OutputSizeAudioData, inputSizeAudioData );

    % The most important line of code:
    PB = ProgressBar( numAudioFiles*numAugmentations, 'Preprocessing Data','cli');


    parfor cntFile = 1 : numAudioFiles 
        cntFile;

        % Read an audio file
        fileToRead = filesTrain( cntFile );
        [ audioIn, ~ ] = audioread( strcat( fileToRead.folder, '/', fileToRead.name ));
        

        % Loop over augmentations:
        for augmentCount = 1 : numAugmentations
            
            % Select a number of leading zeros and add them before the
            % audio signal
            curNumLeadingZeroes = round( rand()*  maxLeadingZeroes + 1 );
            audioInTemp = [ zeros( curNumLeadingZeroes, 1 ) ; audioIn ]; 

            % Do the post-signal zero padding and measure length:
            audioInZeropad = zeros( OutputSizeAudioData, 1 );
            audioInZeropad( 1 : length( audioInTemp ) ) = audioInTemp;
            curLengthAudio = length( audioInTemp );
    
            % Scale to max of 1 for each signal:
            audioInZeropad = audioInZeropad / max(abs(audioInZeropad(:)));
            % Add in some noise. This helps to not have that many zeros in
            % the target vector
            audioInZeropad = audioInZeropad + 0.001*randn(size(audioInZeropad) )
            
            % Now, we do the real compression. First, allocate data:
            sigCompressed = zeros( inputSizeAudioData, numCompressionEmbeddings );
            for cntSig = 1 : numCompressionEmbeddings
                % Select the current random sampling index:
                curIdxRandom = allSampleIndexesEmbeddingSize( :, cntSig );
                % Sample the signal randomly
                curSignalRandomSampled = audioInZeropad( curIdxRandom )
                % Resample to the uniform sampling using interp1:
                curSignalRandomInterpolated = interp1( curIdxRandom, curSignalRandomSampled, sampleTimesLinear, 'linear', 'extrap' )
                % Store this in the sigCompressed matrix
                sigCompressed( :, cntSig ) = curSignalRandomInterpolated;
            end

            % Save the data:
            curFnSave = sprintf( 'lungsoundTrainPreprocessed_%05d_augment_%02d.mat', cntFile, augmentCount );
            fullfileSave = strcat( folderSavePreprocessed, '/', curFnSave )    
            assert( length(audioInZeropad) <= OutputSizeAudioData )
            cellArraySave = cell(1,2);
            cellArraySave{1} = sigCompressed;
            cellArraySave{2} = audioInZeropad;
            saveDataParfor(fullfileSave, cellArraySave)   
            
            count(PB)
        end
        % end
      
    end

    % Now make some settings to be stored, so that we can apply the same
    % stuff later in a test scenario:
    settingsDataPreprocessing = struct();
    settingsDataPreprocessing.fsAudio = fsAudio;
    settingsDataPreprocessing.numCompressionEmbeddings = numCompressionEmbeddings;
    settingsDataPreprocessing.compressionFactorReal = compressionFactorReal;
    settingsDataPreprocessing.allSampleIndexesEmbeddingSize = allSampleIndexesEmbeddingSize;
    settingsDataPreprocessing.sampleTimesLinear = sampleTimesLinear;
    settingsDataPreprocessing.numTimeSamplesInSingleCompression = numTimeSamplesInSingleCompression;
    settingsDataPreprocessing.maxLeadingZeroes = maxLeadingZeroes;
    settingsDataPreprocessing.numAudioFiles = numAudioFiles;
    settingsDataPreprocessing.numAugmentations = numAugmentations;
    settingsDataPreprocessing.inputSizeAudioData = inputSizeAudioData;
    settingsDataPreprocessing.OutputSizeAudioData = OutputSizeAudioData;

    fullfileSave = strcat( folderSavePreprocessed, '/', 'settingsDataPreprocessing.mat' );   
    save( fullfileSave, 'settingsDataPreprocessing' );