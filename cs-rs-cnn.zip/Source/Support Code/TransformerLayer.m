classdef TransformerLayer < nnet.layer.Layer & nnet.layer.Formattable & nnet.layer.Acceleratable

    properties (Learnable, State)
        tfNetwork
    end

    methods
        function layer = TransformerLayer( tfName, percentageDropout, layernormEpsilon, numHeads,numKeyChannels, numValueChannels, projectionSize, outputSize  )
            layer.Name = tfName;
            layer.Description = "A transformer block";
            layer.Type = "Transformer Block";
            
            nameDropoutInput = strcat( tfName, "_input" );
            nameSelfAttention = strcat( tfName, "_SelfAttention" );
            nameDropout1 = strcat( tfName, "_dropout1" );
            nameDropout2 = strcat( tfName, "_dropout2" );
            nameAdd1 = strcat( tfName, "_add1");
            nameAdd2 = strcat( tfName, "_output");
            nameLayernorm1 = strcat( tfName, "_layernorm1" );
            nameLayernorm2 = strcat( tfName, "_layernorm2" );
            nameConv1d = strcat( tfName, "_conv1d" );
            nameConv1dProjection = strcat( tfName, "_conv1dProjection" );
            nameGeLu = strcat( tfName, "_gelu" );
            
            net = dlnetwork;
          
            tempLayers = [ dropoutLayer( percentageDropout,"Name", nameDropoutInput ) ];
            net = addLayers(net, tempLayers);

            tempLayers = [
            %layerNormalizationLayer("Name",nameLayernorm1,"Epsilon",layernormEpsilon)
            batchNormalizationLayer("Name",nameLayernorm1 )
            selfAttentionLayer(numHeads, numKeyChannels, "Name",nameSelfAttention,"DropoutProbability",percentageDropout,"NumValueChannels",numValueChannels,"OutputSize",outputSize)
            dropoutLayer(0.1,"Name",nameDropout1)];
            net = addLayers(net,tempLayers);
            
            tempLayers = additionLayer(2,"Name",nameAdd1);
            net = addLayers(net,tempLayers);
            
            tempLayers = [
            % layerNormalizationLayer("Name",nameLayernorm2,"Epsilon",layernormEpsilon)
            batchNormalizationLayer("Name",nameLayernorm2 )
            convolution1dLayer(1,projectionSize,"Name",nameConv1dProjection)
            geluLayer("Name",nameGeLu,"Approximation","tanh")
            convolution1dLayer(1,outputSize,"Name",nameConv1d)
            dropoutLayer(percentageDropout,"Name",nameDropout2)];
            net = addLayers(net,tempLayers);
            
            tempLayers = [
            additionLayer(2,"Name",nameAdd2)
            ];
            net = addLayers(net,tempLayers);
                
            net = connectLayers(net,nameDropoutInput,nameLayernorm1);
            net = connectLayers(net,nameDropoutInput,strcat( nameAdd1, "/in2" ));
            net = connectLayers(net,nameDropout1,strcat( nameAdd1, "/in1" ));
            net = connectLayers(net,nameAdd1,nameLayernorm2);
            net = connectLayers(net,nameAdd1,strcat( nameAdd2, "/in2" ));
            net = connectLayers(net,nameDropout2,strcat( nameAdd2, "/in1" ));
            layer.tfNetwork = net;

        end        

        function [Y,state] = predict(layer,X)
            net = layer.tfNetwork;

            % tic
            [Y,state] = predict(net,(X));
            % toc
        end

        
    end
end