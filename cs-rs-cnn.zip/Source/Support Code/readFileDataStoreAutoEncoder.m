

function [cellArrayOutput] = readFileDataStoreAutoEncoder( fileName )
    load( fileName );
    % cellArraySave= cellArraySave';
    cellArrayOutput = cell(1,2);
    cellArrayOutput{1} = single(cellArraySave{2} );
    cellArrayOutput{2} = single(cellArraySave{2} );

end

