function [neNumber, crNumber] = extractNumbersFromPath(filePath)
    % This function extracts numbers following 'NE' and 'CR' in the given file path.
    
    % Pattern to find 'NE' followed by any digits
    nePattern = 'NE(\d+)';
    % Extracting the number following 'NE'
    neToken = regexp(filePath, nePattern, 'tokens');
    if ~isempty(neToken)
        neNumber = str2double(neToken{1}{1});
    else
        neNumber = [];
        disp('No "NE" number found.');
    end
    
    % Pattern to find 'CR' followed by any digits
    crPattern = 'CR(\d+)';
    % Extracting the number following 'CR'
    crToken = regexp(filePath, crPattern, 'tokens');
    if ~isempty(crToken)
        crNumber = str2double(crToken{1}{1});
    else
        crNumber = [];
        disp('No "CR" number found.');
    end
end
