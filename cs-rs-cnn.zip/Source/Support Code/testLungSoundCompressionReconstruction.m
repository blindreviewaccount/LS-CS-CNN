
%% Init:

    close all
    clear
    clc

%% 

    folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed1'


%%  Load a data:

    audioDataStore = fileDatastore( folderTrain, "ReadFcn", @readFileDataStore )

    percentageTrain = 0.9;

    [idxTrain, idxVal, idxTest ] = dividerand( size(audioDataStore.Files,1), percentageTrain, 1-percentageTrain, 0);
    
    audioDataStoreTrain = fileDatastore( audioDataStore.Files(idxTrain), "ReadFcn", @readFileDataStore );
    audioDataStoreValid = fileDatastore( audioDataStore.Files(idxVal), "ReadFcn", @readFileDataStore );

%% Make the network:

    net = dlnetwork;

    tempNet = imageInputLayer([3687 5 1],"Name","imageinput");
    net = addLayers(net,tempNet);
    
    tempNet = [
        patchEmbeddingLayer([1 5],400,"Name","patchembed")
        TransformerLayer( "TF1", 0.2, 1e-6, 10, 400, 400, 1000, 400 )
        TransformerLayer( "TF2", 0.2, 1e-6, 10, 400, 400, 1000, 400 )
        TransformerLayer( "TF3", 0.2, 1e-6, 10, 400, 400, 1000, 400 )
        TransformerLayer( "TF4", 0.2, 1e-6, 10, 400, 400, 1000, 400 )
        TransformerLayer( "TF5", 0.2, 1e-6, 10, 400, 400, 1000, 400 )
        functionLayer(@(x)reshapeDLArray(x),"Formattable",true,"Acceleratable",true,"Name",'function',"Description",'@(x)x')];
    net = addLayers(net,tempNet);
    
    tempNet = [
        transposedConv2dLayer([10 5],16,"Name","transposed-conv","Cropping","same","Stride",[1 5])
        leakyReluLayer(0.01,"Name","leakyrelu")
        batchNormalizationLayer("Name","batchnorm")
        transposedConv2dLayer([10 5],16,"Name","transposed-conv_4","Cropping","same","Stride",[1 5])
        leakyReluLayer(0.01,"Name","leakyrelu_1")
        batchNormalizationLayer("Name","batchnorm_1")
        transposedConv2dLayer([10 5],8,"Name","transposed-conv_5","Cropping","same","Stride",[1 3])
        leakyReluLayer(0.01,"Name","leakyrelu_1_1")
        batchNormalizationLayer("Name","batchnorm_1_1")];
    net = addLayers(net,tempNet);
    
    tempNet = resize2dLayer("Name","resize-reference-input_1","EnableReferenceInput",true,"GeometricTransformMode","half-pixel","Method","nearest","NearestRoundingMode","round");
    net = addLayers(net,tempNet);
    
    tempNet = [
        depthConcatenationLayer(2,"Name","depthcat_1")
        convolution2dLayer([10 5],16,"Name","conv","Padding","same","Stride",[1 5])
        leakyReluLayer(0.01,"Name","leakyrelu_3_1")
        batchNormalizationLayer("Name","batchnorm_3_1")
        convolution2dLayer([10 5],16,"Name","conv_1","Padding","same","Stride",[1 5])
        leakyReluLayer(0.01,"Name","leakyrelu_3_2")
        batchNormalizationLayer("Name","batchnorm_3_2")
        transposedConv2dLayer([10 5],16,"Name","transposed-conv_1","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu_3")
        batchNormalizationLayer("Name","batchnorm_3")
        transposedConv2dLayer([10 5],8,"Name","transposed-conv_2","Cropping","same","Stride",[10 1])
        leakyReluLayer(0.01,"Name","leakyrelu_4")
        batchNormalizationLayer("Name","batchnorm_4")];
    net = addLayers(net,tempNet);
    
    tempNet = resize2dLayer("Name","resize-reference-input","EnableReferenceInput",true,"GeometricTransformMode","half-pixel","Method","bilinear","NearestRoundingMode","round");
    net = addLayers(net,tempNet);
    
    tempNet = [
        depthConcatenationLayer(2,"Name","depthcat")
        transposedConv2dLayer([10 5],32,"Name","transposed-conv_3","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu_5")
        batchNormalizationLayer("Name","batchnorm_5")
        transposedConv2dLayer([10 5],5,"Name","transposed-conv_3_1","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu_5_1")
        batchNormalizationLayer("Name","batchnorm_5_1")
        resize2dLayer("Name","resize-output-size","GeometricTransformMode","half-pixel","Method","nearest","NearestRoundingMode","round","OutputSize",[73728 5])
        convolution2dLayer([10 5],1,"Name","conv_2","Padding","same")
        averagePooling2dLayer([1 5],"Name","avgpool2d","Padding","same","Stride",[1 5])];
    net = addLayers(net,tempNet);
    
    % clean up helper variable
    clear tempNet;   

    net = connectLayers(net,"imageinput","patchembed");
    net = connectLayers(net,"imageinput","transposed-conv");
    net = connectLayers(net,"imageinput","resize-reference-input/in");
    net = connectLayers(net,"function","resize-reference-input_1/ref");
    net = connectLayers(net,"function","depthcat_1/in1");
    net = connectLayers(net,"batchnorm_1_1","resize-reference-input_1/in");
    net = connectLayers(net,"resize-reference-input_1","depthcat_1/in2");
    net = connectLayers(net,"batchnorm_4","resize-reference-input/ref");
    net = connectLayers(net,"batchnorm_4","depthcat/in2");
    net = connectLayers(net,"resize-reference-input","depthcat/in1");
    netLungsoundUncompressor = initialize(net);
%% Compress the data:    
    
      trainingoptsFull = trainingOptions('adam', ...
        'MaxEpochs', 1000, ...
        'MiniBatchSize', 10, ...
        'InitialLearnRate', 1e-4, ...
        'LearnRateSchedule','none', ...
        'LearnRateDropPeriod', 10, ...
        'LearnRateDropFactor', 0.97, ...
        'Plots', 'training-progress', ...
        'OutputNetwork', 'best-validation', ...
        'Shuffle', 'every-epoch', ...
        'ValidationFrequency',100, ...
        'ValidationPatience', inf, ...
        'InputDataFormats', {'SSCB'}) ;

        trainingoptsFull.ValidationData = audioDataStoreValid;
        
        
        % load( 'net_1_LargeConv.mat' );
        netTrained =  trainnet( audioDataStoreTrain, net_2 , 'mse', trainingoptsFull );

        % netTrained =  trainnet( audioDataStoreTrain, netLungsoundUncompressor , @(Y,T)customLungSoundLoss(Y,T), trainingoptsFull )


        % [ bLPLoss, aLPLoss ] = butter( 2, 500 / 4000 );
        % netTrained =  trainnet( audioDataStoreTrain, netLungsoundUncompressor , @(Y,T)customLungSoundLossSmooth(Y,T,bLPLoss, aLPLoss), trainingoptsFull )

%%

        sampleTest = read( audioDataStoreTrain );

        dataPredict = double( predict( netTrained, sampleTest{1} ) );



        figure; plot( dataPredict )
        hold on;
        plot( sampleTest{2}+1) 
        
        
        figure; plot( medfilt1( sampleTest{2}, 21) )
        hold on;
        plot( ( sampleTest{2}) )

    