

function [cellArrayOutput] = readFileDataStore( fileName )
    load( fileName );
    % cellArraySave= cellArraySave';
    cellArrayOutput = cell(1,2);
    cellArrayOutput{1} = single( cellArraySave{1} );
    cellArrayOutput{2} = single(cellArraySave{2} );

end

