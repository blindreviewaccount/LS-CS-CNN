function saveDataParfor(filenameToSave, cellArraySave)


        save( filenameToSave, 'cellArraySave' )

end

