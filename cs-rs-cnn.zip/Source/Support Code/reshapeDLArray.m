

function [Y] = reshapeDLArray(X)

    sizeInput = size(X);

    Y = dlarray( reshape( stripdims( X), [ sizeInput(1) sizeInput(2) 1 sizeInput(3) ] ), 'SSCB' );

end

