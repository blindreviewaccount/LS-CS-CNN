

function [cellArrayOutput] = readFileDataStore( fileName )
    load( fileName );
    % cellArraySave= cellArraySave';
    cellArrayOutput = cell(1,3);
    % cellArrayOutput{1} = dlarray( gpuArray( single( cellArraySave{1} ) ), "SC" );
    % cellArrayOutput{2} = dlarray( gpuArray( single(cellArraySave{2} ) ), "SC" );
    % cellArrayOutput{3} = dlarray( gpuArray( single(cellArraySave{3} ) ), "SC" );
    cellArrayOutput{1} = single(cellArraySave{1} );
    cellArrayOutput{2} = single(cellArraySave{2} );
    cellArrayOutput{3} = single(cellArraySave{3} );
end

