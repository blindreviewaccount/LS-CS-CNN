
%% Init:

    close all
    clear
    clc

%% 

    folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed1'


%%  Load a data:

    audioDataStore = fileDatastore( folderTrain, "ReadFcn", @readFileDataStoreAutoEncoder)

    percentageTrain = 0.9;

    [idxTrain, idxVal, idxTest ] = dividerand( size(audioDataStore.Files,1), percentageTrain, 1-percentageTrain, 0);
    
    audioDataStoreTrain = fileDatastore( audioDataStore.Files(idxTrain), "ReadFcn", @readFileDataStoreAutoEncoder );
    audioDataStoreValid = fileDatastore( audioDataStore.Files(idxVal), "ReadFcn", @readFileDataStoreAutoEncoder );

%% Compress the data:    
    
      trainingoptsFull = trainingOptions('adam', ...
        'MaxEpochs', 1000, ...
        'MiniBatchSize', 10, ...
        'InitialLearnRate', 1e-2, ...
        'LearnRateSchedule','none', ...
        'LearnRateDropPeriod', 10, ...
        'LearnRateDropFactor', 0.97, ...
        'Plots', 'training-progress', ...
        'OutputNetwork', 'best-validation', ...
        'Shuffle', 'every-epoch', ...
        'ValidationFrequency',100, ...
        'ValidationPatience', inf, ...
        'InputDataFormats', {'SSCB'}) ;

        trainingoptsFull.ValidationData = audioDataStoreValid;
        
        
        
        load( 'net_2_autoencoder.mat' )
        netTrained =  trainnet( audioDataStoreTrain, net_6 , "mae", trainingoptsFull )
        % bLPLoss = 1;
        % aLPLoss = 1;
        % netTrained =  trainnet( audioDataStoreTrain, net_6, @(Y,T)customLungSoundLossSmooth(Y,T,bLPLoss, aLPLoss), trainingoptsFull )

%%

        sampleTest = read( audioDataStoreTrain );

        dataPredict = double( predict( netTrained, sampleTest{1} ) );



        figure; plot( dataPredict )
        hold on;
        plot( sampleTest{2}+1) 
        
        
        % figure; plot( medfilt1( sampleTest{2}, 21) )
        % hold on;
        % plot( ( sampleTest{2}) )

    