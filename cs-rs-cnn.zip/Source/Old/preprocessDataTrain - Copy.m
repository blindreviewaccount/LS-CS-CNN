

%% Init:
    close all
    clc

%%

        folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\train_compression_wav'
        folderSavePreprocessed =  'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed1';
        mkdir( folderSavePreprocessed );

        fsAudio = 8000;

        scalerAudio = 5;

        inputSizeAudioData = 69984;
        OutputSizeAudioData = inputSizeAudioData*2;
%% 

    filesTrain = dir( strcat( folderTrain, '/*.wav' ) );
   

    numCompressionEmbeddings = 5;

    compressionRandomSignals = rand( OutputSizeAudioData, numCompressionEmbeddings ) - 0.5;
    
    compressionFactorReal = 3;


    compressionFactorTime = numCompressionEmbeddings*compressionFactorReal;

    lowpassFreqCompression = fsAudio/compressionFactorTime / 2.5;

    freqRangesCompressionNoiseFilter = zeros( numCompressionEmbeddings, 2 );
    for cntEmbedding = 1 : numCompressionEmbeddings
        freqCompressionNoiseFilterStart = 2+ 100*rand(1);
        freqCompressionNoiseFilterEnd = freqCompressionNoiseFilterStart + 1000*rand(1);

        freqRangesCompressionNoiseFilter( cntEmbedding, 1 ) = freqCompressionNoiseFilterStart;
        freqRangesCompressionNoiseFilter( cntEmbedding, 2 ) = freqCompressionNoiseFilterEnd;
        [ bBP, aBP ] = butter( 2, [ freqCompressionNoiseFilterStart freqCompressionNoiseFilterEnd ] / ( fsAudio/2) );

        compressionRandomSignals( :, cntEmbedding ) = filter( bBP, aBP, compressionRandomSignals( :, cntEmbedding ) ); 
    end


    [ bLPCompression, aLPCompression ] = butter( 2, lowpassFreqCompression / (fsAudio/2 ) );
    numAudioFiles = length( filesTrain );


    PB = ProgressBar( numAudioFiles, 'Preprocessing Data','cli');
    parfor cntFile = 1 : numAudioFiles 
        cntFile;
        fileToRead = filesTrain( cntFile );
        [ audioIn, fsAudio ] = audioread( strcat( fileToRead.folder, '/', fileToRead.name ));
        
        audioInZeropad = zeros( OutputSizeAudioData, 1 );
        audioInZeropad( 1 : length( audioIn ) ) = audioIn;
        curLengthAudio = length( audioIn );

        audioInZeropad = audioInZeropad * scalerAudio;
        audioInZeropad = audioInZeropad / max(abs(audioInZeropad(:)));
        
        sigProjected = audioInZeropad .* compressionRandomSignals;
        sigProjectedFiltered = filter( bLPCompression, aLPCompression, sigProjected, [], 1 );
        sigCompressed = sigProjectedFiltered( 1 : compressionFactorTime : end, :);
        sigCompressed = sigCompressed / max(abs(sigCompressed(:)));

        curFnSave = sprintf( 'lungsoundTrainPreprocessed_%05d.mat', cntFile );
        fullfileSave = strcat( folderSavePreprocessed, '/', curFnSave );

        
        sigCompressedResampled = resample( sigCompressed,inputSizeAudioData, size( sigCompressed,1)  );

        cellArraySave = cell(1,2);
        cellArraySave{1} = sigCompressedResampled;
        cellArraySave{2} = audioInZeropad;

        % save( fullfileSave, 'cellArraySave' )
        saveDataParfor(fullfileSave, cellArraySave) 
        % end
        count(PB)
    end