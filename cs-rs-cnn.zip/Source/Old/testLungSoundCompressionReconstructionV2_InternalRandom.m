
%% Init:

    close all
    clear
    clc

%% 

    % folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed1';
    folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed_Using_RandomSampling';
    folderTrain = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\Preprocessed_AutoEncoder';

%%  Load a data:

    audioDataStore = fileDatastore( folderTrain, "ReadFcn", @readFileDataStore );

    percentageTrain = 0.97;

    [idxTrain, idxVal, idxTest ] = dividerand( size(audioDataStore.Files,1), percentageTrain, 1-percentageTrain, 0);
    
    audioDataStoreTrain = fileDatastore( audioDataStore.Files(idxTrain), "ReadFcn", @readFileDataStore );
    audioDataStoreValid = fileDatastore( audioDataStore.Files(idxVal), "ReadFcn", @readFileDataStore );

%% Make the network:

    inputLength = 130000;
    outputLengthRandomSample = 7000;
    embeddingLengthRS = 5000;
    numChannelsRS = 5;

    net = dlnetwork;
    tempNet = imageInputLayer([inputLength 1 1],"Name","imageinput");
    net = addLayers(net,tempNet);
    

    tempNet = [
        convolution2dLayer([100 1],5,"Name","conv","Padding","same")
        reluLayer("Name","relu")
        RandomSampleLayer( "rs1", inputLength, outputLength, embeddingLength, numChannels )
        transposedConv2dLayer([200 1],32,"Name","transposed-conv","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu")
        batchNormalizationLayer("Name","batchnorm")
        transposedConv2dLayer([200 3],32,"Name","transposed-conv_1","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu_1")
        batchNormalizationLayer("Name","batchnorm_1")
        transposedConv2dLayer([200 1],32,"Name","transposed-conv_2","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu_2")
        batchNormalizationLayer("Name","batchnorm_2")
        transposedConv2dLayer([200 1],32,"Name","transposed-conv_3","Cropping","same","Stride",[2 1])
        leakyReluLayer(0.01,"Name","leakyrelu_3")
        batchNormalizationLayer("Name","batchnorm_3")
        convolution2dLayer([100 1],1,"Name","conv_1","Padding","same")];
    net = addLayers(net,tempNet);
    
    tempNet = [
        resize2dLayer("Name","resize-reference-input","EnableReferenceInput",true,"GeometricTransformMode","half-pixel","Method","nearest","NearestRoundingMode","round")
        convolution2dLayer([50 1],32,"Name","conv_2","Padding","same")
        leakyReluLayer(0.01,"Name","leakyrelu_4")
        convolution2dLayer([50 1],1,"Name","conv_3","Padding","same")];
    net = addLayers(net,tempNet);
    
    % clean up helper variable
    clear tempNet;
    
    net = connectLayers(net,"imageinput","conv");
    net = connectLayers(net,"imageinput","resize-reference-input/ref");
    net = connectLayers(net,"conv_1","resize-reference-input/in");
    netConvolutionalUncompressor = initialize(net);
%% Compress the data:    
    
      trainingoptsFull = trainingOptions('adam', ...
        'MaxEpochs', 20, ...
        'MiniBatchSize',10, ...
        'InitialLearnRate', 1e-5, ...
        'LearnRateSchedule','none', ...
        'LearnRateDropPeriod', 2, ...
        'LearnRateDropFactor', 0.98, ...
        'Plots', 'training-progress', ...
        'OutputNetwork', 'best-validation', ...
        'Shuffle', 'every-epoch', ...
        'ValidationFrequency',200, ...
        'ValidationPatience', inf, ...
        'InputDataFormats', {'SSCB'}) ;

        trainingoptsFull.ValidationData = audioDataStoreValid;
        
        audioDataStoreTrain = shuffle( audioDataStoreTrain );

        % netTrained =  trainnet( audioDataStoreTrain, netConvolutionalUncompressor , @(Y,T)customLungSoundLoss(Y, T), trainingoptsFull );
        netTrained =  trainnet( audioDataStoreTrain, netConvolutionalUncompressor , 'mse', trainingoptsFull );



    fnSave = strcat( 'LungSoundNet_Trained_', datestr( now, 'YYYYmmDD_HHMMSS' ), '.mat' );
    save( fnSave, 'netTrained' )

%%

        sampleTest = read( audioDataStoreTrain );

        dataPredict = double( predict( netTrained, sampleTest{1} ) );

        figure; plot( dataPredict +1)
        hold on;
        plot( sampleTest{2}) 
        
        
   
    