

%% Init:
    close all
    clc

%%

        % folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\train_compression_wav'
        folderTrain = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\train_compression_wav'


        % folderSavePreprocessed =  'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed_Using_RandomSampling';
        folderSavePreprocessed =  'E:\Data Deeplearning\20240502 - Lung Sound Competition\Preprocessed_AutoEncoder';

        mkdir( folderSavePreprocessed );

        fsAudio = 8000;

        scalerAudio = 5;

        
        OutputSizeAudioData = 130000;

        numAugmentations = 1;
        maxLeadingZeroes = 3000;
%% 

    filesTrain = dir( strcat( folderTrain, '/*.wav' ) );
   

    % numCompressionEmbeddings = 5;
    % compressionRandomSignals = rand( OutputSizeAudioData, numCompressionEmbeddings ) - 0.5;
    % compressionFactorReal = 5;
    % compressionFactorTime = numCompressionEmbeddings*compressionFactorReal;
    % 
    % numTimeSamplesInSingleCompression = round( OutputSizeAudioData / compressionFactorTime );
    % 
    % lowpassFreqCompression = fsAudio/compressionFactorTime / 2;
    % 
    % [ bLPCompression, aLPCompression ] = butter( 2, lowpassFreqCompression / (fsAudio/2 ) );
    numAudioFiles = length( filesTrain );


    PB = ProgressBar( numAudioFiles*numAugmentations, 'Preprocessing Data','cli');
    % 
    % allSampleIndexes = repmat( (1 : OutputSizeAudioData)', 1, numCompressionEmbeddings );
    % 
    % randomIndexSampling = zeros( size(allSampleIndexes) );
    % for cntEmbedding = 1 : numCompressionEmbeddings
    %     allSampleIndexes( :, cntEmbedding ) = randperm( OutputSizeAudioData );
    % end
    % 
    % allSampleIndexesOutputSize = allSampleIndexes( 1 : numTimeSamplesInSingleCompression, : );
    % allSampleIndexesOutputSize = sort(allSampleIndexesOutputSize, 1 );
    % 
    % sampleTimesLinear = linspace( 1, OutputSizeAudioData, inputSizeAudioData );

    parfor cntFile = 1 : numAudioFiles 
        cntFile;
        fileToRead = filesTrain( cntFile );
        [ audioIn, fsAudio ] = audioread( strcat( fileToRead.folder, '/', fileToRead.name ));
        

        for augmentCount = 1 : numAugmentations
            
            curNumLeadingZeroes = round( rand()*  maxLeadingZeroes + 1 );
            audioInTemp = [ zeros( curNumLeadingZeroes, 1 ) ; audioIn ]; 
            audioInZeropad = zeros( OutputSizeAudioData, 1 );
            audioInZeropad( 1 : length( audioInTemp ) ) = audioInTemp;
            curLengthAudio = length( audioInTemp );
    
            audioInZeropad = audioInZeropad * scalerAudio;
            audioInZeropad = audioInZeropad / max(abs(audioInZeropad(:)));
            
            audioInZeropad = audioInZeropad + 0.001*randn(size(audioInZeropad) );
            
            curFnSave = sprintf( 'lungsoundTrainPreprocessed_%05d_augment_%02d.mat', cntFile, augmentCount );
            fullfileSave = strcat( folderSavePreprocessed, '/', curFnSave )    
            
            
            assert( length(audioInZeropad) <= OutputSizeAudioData )

            cellArraySave = cell(1,2);
            cellArraySave{1} = audioInZeropad;
            cellArraySave{2} = audioInZeropad;
    
            % save( fullfileSave, 'cellArraySave' )
            saveDataParfor(fullfileSave, cellArraySave)   
            
            count(PB)
        end
        % end
      
    end