function loss = customLungSoundLossSmooth(Y, T, bLP, aLP)
            batchSize = size( Y, 4 );
            

            % YForSTFT = real( dlarray( permute( stripdims(Y), [ 2 4 1 3 ]) , 'CBT' ) );
            % TForSTFT = real( dlarray( permute( stripdims(T), [ 2 4 1 3 ]) , 'CBT' ) );
            % 
            % YSTFT = real( abs( dlstft( YForSTFT ) ) );
            % TSTFT = real( abs( dlstft( TForSTFT ) ) );
            % 
            % 
            % loss = sqrt( sum(  ( YSTFT(:) - TSTFT(:) ).^2 ) );

            loss = sqrt( sum( ( (100*Y(1:73728,:,:,:) - 100*T ) ).^2, 'all'  ) )/ batchSize ;
            % lossoutputNorm = sum( 1./sqrt( sum( squeeze(Y).^2 , 1 ) ) ) / batchSize;
            % 
            % loss = lossMSE + 1000*lossoutputNorm;

            % loss = huber( Y, T ) / batchSize;

end

