

%% Init:
    close all
    clc

%%

        folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\train_compression_wav'
        folderSavePreprocessed =  'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed_Using_RandomSampling';
        mkdir( folderSavePreprocessed );

        fsAudio = 8000;

        scalerAudio = 5;

        inputSizeAudioData = 34976;
        OutputSizeAudioData = inputSizeAudioData*4;

        numAugmentations = 15;
        maxLeadingZeroes = 3000;
%% 

    filesTrain = dir( strcat( folderTrain, '/*.wav' ) );
   

    numCompressionEmbeddings = 5;

    compressionRandomSignals = rand( OutputSizeAudioData, numCompressionEmbeddings ) - 0.5;
    
    compressionFactorReal = 5;


    compressionFactorTime = numCompressionEmbeddings*compressionFactorReal;

    lowpassFreqCompression = fsAudio/compressionFactorTime / 2;
    
    % freqRangesCompressionNoiseFilter = zeros( numCompressionEmbeddings, 2 );
    % for cntEmbedding = 1 : numCompressionEmbeddings
    %     freqCompressionNoiseFilterStart = 2+ 100*rand(1);
    %     freqCompressionNoiseFilterEnd = freqCompressionNoiseFilterStart + 1000*rand(1);
    % 
    %     freqRangesCompressionNoiseFilter( cntEmbedding, 1 ) = freqCompressionNoiseFilterStart;
    %     freqRangesCompressionNoiseFilter( cntEmbedding, 2 ) = freqCompressionNoiseFilterEnd;
    %     [ bBP, aBP ] = butter( 2, [ freqCompressionNoiseFilterStart freqCompressionNoiseFilterEnd ] / ( fsAudio/2) );
    % 
    %     compressionRandomSignals( :, cntEmbedding ) = filter( bBP, aBP, compressionRandomSignals( :, cntEmbedding ) ); 
    % end


    [ bLPCompression, aLPCompression ] = butter( 2, lowpassFreqCompression / (fsAudio/2 ) );
    numAudioFiles = length( filesTrain );


    PB = ProgressBar( numAudioFiles*numAugmentations, 'Preprocessing Data','cli');

    allSampleIndexes = repmat( (1 : OutputSizeAudioData)', 1, numCompressionEmbeddings );
    
    randomIndexSampling = zeros( size(allSampleIndexes) );
    


    parfor cntFile = 1 : numAudioFiles 
        cntFile;
        fileToRead = filesTrain( cntFile );
        [ audioIn, fsAudio ] = audioread( strcat( fileToRead.folder, '/', fileToRead.name ));
        

        for augmentCount = 1 : numAugmentations
            
            curNumTrailingZeroes = round( rand()*  maxLeadingZeroes + 1 );
            audioInTemp = [ zeros( curNumTrailingZeroes, 1 ) ; audioIn ]; 
            audioInZeropad = zeros( OutputSizeAudioData, 1 );
            audioInZeropad( 1 : length( audioInTemp ) ) = audioInTemp;
            curLengthAudio = length( audioInTemp );
    
            audioInZeropad = audioInZeropad * scalerAudio;
            audioInZeropad = audioInZeropad / max(abs(audioInZeropad(:)));
            
            audioInZeropad = audioInZeropad + 0.005*randn(size(audioInZeropad) )


            sigProjected = audioInZeropad .* compressionRandomSignals;
            sigProjectedFiltered = filter( bLPCompression, aLPCompression, sigProjected, [], 1 );
            sigCompressed = sigProjectedFiltered( 1 : compressionFactorTime : end, :);
            sigCompressed = sigCompressed / max(abs(sigCompressed(:)));
    
            curFnSave = sprintf( 'lungsoundTrainPreprocessed_%05d_augment_%02d.mat', cntFile, augmentCount );
            fullfileSave = strcat( folderSavePreprocessed, '/', curFnSave );
    
            
            sigCompressedResampled = resample( sigCompressed,inputSizeAudioData, size( sigCompressed,1)  );
            
            assert( length(audioInZeropad) <= OutputSizeAudioData )

            cellArraySave = cell(1,2);
            cellArraySave{1} = sigCompressedResampled;
            cellArraySave{2} = audioInZeropad;
    
            % save( fullfileSave, 'cellArraySave' )
            saveDataParfor(fullfileSave, cellArraySave)   
            
            count(PB)
        end
        % end
      
    end