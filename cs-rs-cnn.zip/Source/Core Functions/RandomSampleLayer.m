classdef RandomSampleLayer < nnet.layer.Layer & nnet.layer.Formattable & nnet.layer.Acceleratable

    properties
        allSampleIndexesEmbeddingSize
        sampleTimesLinear
        outputLength
        inputLength
        embeddingLength
        numChannels
    end

    methods
        function layer = RandomSampleLayer( tfName, inputLength, outputLength, embeddingLength, numChannels )
            layer.Name = tfName;
            layer.Description = "A Random Sample Layer";
            layer.Type = "Random Sample Layer Block";
            
            numCompressionEmbeddings = numChannels;

            
            numTimeSamplesInSingleCompression = embeddingLength;
            
            allSampleIndexes = repmat( (1 : inputLength)', 1, numCompressionEmbeddings );
            
            for cntEmbedding = 1 : numCompressionEmbeddings
                allSampleIndexes( :, cntEmbedding ) = randperm( inputLength );
            end
            
            allSampleIndexesEmbeddingSize= allSampleIndexes( 1 : numTimeSamplesInSingleCompression, : );
            layer.allSampleIndexesEmbeddingSize = sort(allSampleIndexesEmbeddingSize, 1 );
            
            layer.sampleTimesLinear = linspace( 1, inputLength, outputLength );

            layer.outputLength = outputLength;
            layer.inputLength = inputLength;
            layer.embeddingLength = embeddingLength;
            layer.numChannels = numChannels;
          

        end        

        function [Y] = predict(layer,X)


            batchSize = size( X, 4 );
            Y = dlarray( zeros( [ layer.outputLength 1 layer.numChannels batchSize ] ), "SSCB" );



            for cntSig = 1 : layer.numChannels
                idxEmbed = layer.allSampleIndexesEmbeddingSize(:,cntSig);
                Y( :, :, cntSig, : ) = permute( interp1( idxEmbed, X(idxEmbed, 1, cntSig, :), layer.sampleTimesLinear, 'linear', 'extrap' ), [ 2 1 3 4 ] );
            end

        end

        
    end
end