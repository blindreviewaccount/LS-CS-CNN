classdef SignalUncompressionLayer < nnet.layer.Layer & nnet.layer.Formattable & nnet.layer.Acceleratable


    properties
        numInputSequences
        numRandomSamplesPerSequence
        numFourierEmbeddings
        numOutputSamples
        fourierVector
        numDimensionsTransformer
        numOutputSequences
    end

    properties (Learnable, State)
        netTranformer
        weightsToTransformer
        weightsFromTransformer
    end

    methods
        function layer = SignalUncompressionLayer( layerName, numInputSequences, numOutputSequences, numRandomSamplesPerSequence, numFourierEmbeddings, numOutputSamples, numDimensionsTransformer )
            layer.Name = layerName;
            layer.Description = "A SignalUncompression block";
            layer.Type = "Signal Uncompression Block";

            layer.numInputSequences = numInputSequences;
            layer.numRandomSamplesPerSequence = numRandomSamplesPerSequence;
            layer.numFourierEmbeddings = numFourierEmbeddings;
            layer.numOutputSamples = numOutputSamples;
            layer.numOutputSequences = numOutputSequences;

            layer.NumInputs = 2;
            layer.NumOutputs = 1;

            layer.fourierVector =  linspace( 1, 10, numFourierEmbeddings );
            layer.numDimensionsTransformer = numDimensionsTransformer;

            numTFChannels = numDimensionsTransformer;

            netTranformer = dlnetwork;

            tempLayer = [   
                            inputLayer([numRandomSamplesPerSequence numTFChannels 1],"SCB","Name","input")
                            TransformerLayer( 'TF1', 0.1, 1e-6, 6, numTFChannels, numTFChannels, numTFChannels, numTFChannels )
                            TransformerLayer( 'TF2', 0.1, 1e-6, 6, numTFChannels, numTFChannels, numTFChannels, numTFChannels )
                            TransformerLayer( 'TF3', 0.1, 1e-6, 6, numTFChannels, numTFChannels, numTFChannels, numTFChannels )
                        ];

            layer.netTranformer = addLayers( netTranformer, tempLayer );

            layer.netTranformer = initialize(layer.netTranformer);
            
            numWeightsBeforeTransformerWithFourier =gpuArray(  numInputSequences * ( numFourierEmbeddings + 1 + 1) );
            
            layer.weightsToTransformer = gpuArray( rand( numWeightsBeforeTransformerWithFourier, numTFChannels ) - 0.5 );
            layer.weightsFromTransformer = gpuArray( rand( numTFChannels, numOutputSequences ) - 0.5 );
        end        

        function [curSignalRandomInterpolated, state, a, b] = predict(layer,dataRandom, timeStampsRandom)
            
            % dataRandom = gpuArray( dataRandom );
            % timeStampsRandom = gpuArray( timeStampsRandom );
            timeStamsRandomScaled = timeStampsRandom / max( timeStampsRandom(:));
            
            batchSize = size( timeStamsRandomScaled, 3 );

            sampleVectorScaled = gpuArray( linspace( 0, 1, layer.numOutputSamples ) );
            
            curSignalRandomInterpolated = dlarray( gpuArray( zeros( layer.numOutputSamples, layer.numOutputSequences, batchSize ) ), "SCB" );


            timeStamsRandomScaledAugmented( :, 1, :, : ) = stripdims( timeStamsRandomScaled );
            
            timeStampsEmbedded =  sin( 2*pi* pagemtimes(timeStamsRandomScaledAugmented,  layer.fourierVector ) );
            curRandomTimestampsInFourier = cat( 2, timeStamsRandomScaledAugmented, timeStampsEmbedded );

            dataRandomAugmented( :, 1, :, : ) = dataRandom;
            allDataCombined = cat( 2, dataRandomAugmented, curRandomTimestampsInFourier );

            sizeDataCombined = size(allDataCombined);

            dataToTransformer = reshape( allDataCombined, [ sizeDataCombined(1) sizeDataCombined(2)*sizeDataCombined(3) batchSize ]);

            dataToTransformer = pagemtimes( dataToTransformer, layer.weightsToTransformer );
            
            
            dataThroughTransformer = layer.netTranformer.predict(dataToTransformer );
            

            dataFromTransformer = pagemtimes( dataThroughTransformer, layer.weightsFromTransformer );

            for cntBatch = 1 : batchSize
                for cntSequence = 1 : layer.numOutputSequences
                    try
                        curSignalRandomInterpolated( :, cntSequence, cntBatch ) = interp1( stripdims( timeStamsRandomScaled( :, cntSequence, cntBatch ) ), dataFromTransformer( :, cntSequence, cntBatch ), sampleVectorScaled, 'linear', 'extrap' );
                    catch exceptionInterpolate
                        curSignalRandomInterpolated( :, cntSequence, cntBatch ) = zeros( size( sampleVectorScaled) );
                        warning('on')
                        warning('some thing in interpolation' )
                    end
                end

            end

            % curSignalRandomInterpolated = stripdims( curSignalRandomInterpolated );
            state = [];
            a = [];
            b = [];
        end
    end
end
