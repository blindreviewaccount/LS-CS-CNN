function loss = customLungSoundLoss(Y, T)
            batchSize = size( Y, 4 );
            
            lossMSE = sqrt( sum( ( (10000*Y(:) - 10000*T(:) ) ).^2  ) )/ batchSize ;
            lossoutputNorm = sum( 1./sqrt( sum( squeeze(Y).^2 , 1 ) ) ) / batchSize;
            
            loss = lossMSE + 1000*lossoutputNorm;

            % loss = huber( Y, T ) / batchSize;

end

