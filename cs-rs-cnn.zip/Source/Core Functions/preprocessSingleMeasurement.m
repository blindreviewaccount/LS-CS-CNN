
function [ sigCompressed, audioInZeropad, originalLengthSig, orignalSignalAmplitude ] = preprocessSingleMeasurement( filenameAudio, settingsDataPreprocessing )

    [ audioIn, ~ ] = audioread( filenameAudio);
    
    originalLengthSig = length( audioIn );

    % Do the post-signal zero padding and measure length:
    audioInZeropad = zeros( settingsDataPreprocessing.OutputSizeAudioData, 1 );
    audioInZeropad( 1 : length( audioIn ) ) = audioIn;
    
    orignalSignalAmplitude =  max(abs(audioInZeropad(:)));
    % Scale to max of 1 for each signal:
    audioInZeropad = audioInZeropad / orignalSignalAmplitude;

    sigCompressed = zeros( settingsDataPreprocessing.inputSizeAudioData, settingsDataPreprocessing.numCompressionEmbeddings );
    for cntSig = 1 : settingsDataPreprocessing.numCompressionEmbeddings
        % Select the current random sampling index:
        curIdxRandom = settingsDataPreprocessing.allSampleIndexesEmbeddingSize( :, cntSig );
        % Sample the signal randomly
        curSignalRandomSampled = audioInZeropad( curIdxRandom );
        % Resample to the uniform sampling using interp1:
        curSignalRandomInterpolated = interp1( curIdxRandom, curSignalRandomSampled, settingsDataPreprocessing.sampleTimesLinear, 'linear', 'extrap' );
        % Store this in the sigCompressed matrix
        sigCompressed( :, cntSig ) = curSignalRandomInterpolated;
    end    



end