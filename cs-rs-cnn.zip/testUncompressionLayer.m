 
%% Generate test signals:

    numRandomSamplesAfterUncompression = 36000;    

    OutputSizeAudioData = numRandomSamplesAfterUncompression*4;

    compressionFactorReal = 5;    
    numCompressionEmbeddings = 3;
        folderTrain = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\train_compression_wav\';
    filesTrain = dir( strcat( folderTrain, '/*.wav' ) );

    compressionFactorTime = numCompressionEmbeddings*compressionFactorReal;
    numTimeSamplesInSingleCompression = round( OutputSizeAudioData / compressionFactorTime ); 

    
    allSampleIndexes = repmat( (1 : OutputSizeAudioData)', 1, numCompressionEmbeddings );
    for cntEmbedding = 1 : numCompressionEmbeddings
        allSampleIndexes( :, cntEmbedding ) = randperm( OutputSizeAudioData );
    end
   
    allSampleIndexesEmbeddingSize = allSampleIndexes( 1 : numTimeSamplesInSingleCompression, : );
    allSampleIndexesEmbeddingSize = sort(allSampleIndexesEmbeddingSize, 1 );

    cntFile = 1500;
    fileToRead = filesTrain( cntFile );
    [ audioIn, ~ ] = audioread( strcat( fileToRead.folder, '/', fileToRead.name ));
    audioInZeropad = zeros( OutputSizeAudioData, 1 );
    audioInZeropad( 1 : length( audioIn ) ) = audioIn;
    sigCompressed = zeros( numTimeSamplesInSingleCompression, numCompressionEmbeddings );
    for cntSig = 1 : numCompressionEmbeddings
        % Select the current random sampling index:
        curIdxRandom = allSampleIndexesEmbeddingSize( :, cntSig );
        % Sample the signal randomly
        curSignalRandomSampled = audioInZeropad( curIdxRandom );
    
        sigCompressed( :, cntSig ) = curSignalRandomSampled;
    end

%% Generate the network:

net = dlnetwork;
tempNet = inputLayer([9600 3],"SC","Name","inputData");
net = addLayers(net,tempNet);

tempNet = inputLayer([9600 3],"SC","Name","inputTimestamps");
net = addLayers(net,tempNet);

tempNet = [
    SignalUncompressionLayer( 'RandomUncompressor', numCompressionEmbeddings, 2, numTimeSamplesInSingleCompression, 3, numRandomSamplesAfterUncompression, 300 );
    convolution1dLayer(100,32,"Name","conv1d","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu")
    batchNormalizationLayer("Name","batchnorm")
    transposedConv1dLayer(100,32,"Name","transposed-conv1d","Cropping","same","Stride",2)
    leakyReluLayer(0.01,"Name","leakyrelu_1")
    batchNormalizationLayer("Name","batchnorm_1")
    transposedConv1dLayer(100,32,"Name","transposed-conv1d_1","Cropping","same","Stride",2)
    leakyReluLayer(0.01,"Name","leakyrelu_2")
    batchNormalizationLayer("Name","batchnorm_2")
    convolution1dLayer(100,5,"Name","conv1d_1","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_3")
    batchNormalizationLayer("Name","batchnorm_3")
    convolution1dLayer(100,1,"Name","conv1d_2","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_4")
    batchNormalizationLayer("Name","batchnorm_4")
    resize2dLayer("Name","resize-output-size","GeometricTransformMode","half-pixel","Method","nearest","NearestRoundingMode","round","OutputSize",[140000 1])];
net = addLayers(net,tempNet);

% clean up helper variable
clear tempNet;

net = connectLayers(net,"inputData","RandomUncompressor/in1");
net = connectLayers(net,"inputTimestamps","RandomUncompressor/in2");
net = initialize(net);
%% Now, do a test run:

 curLayer = 

testbatch = cat( 3, sigCompressed, sigCompressed, sigCompressed, sigCompressed, sigCompressed );
testbatch2 = cat( 3, allSampleIndexesEmbeddingSize, allSampleIndexesEmbeddingSize, allSampleIndexesEmbeddingSize, allSampleIndexesEmbeddingSize, allSampleIndexesEmbeddingSize );


[ curOut ] = curLayer.predict( dlarray( gpuArray( testbatch ), "SCB" ), testbatch2 )

figure; plot( curOut )

