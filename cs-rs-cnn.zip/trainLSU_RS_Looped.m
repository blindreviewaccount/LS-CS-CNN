
%% Init:

    close all
    clear
    clc

    close(findall(groot, "Type", "figure"));
    path(pathdef);
    addpath( genpath( 'Source' ) )    



%%  Make the datastores

    % folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed_Using_RandomSampling';
    % foldersTrain = { 
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR5', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE3_CR5', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE4_CR5', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE5_CR2', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE5_CR4', ...            
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE5_CR5', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE5_CR8', ...            
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE5_CR10', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE5_CR15', ...
    %         };

    % foldersTrain = { 
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR5', ...
    %         };
    
    % foldersTrain = { 
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR2', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR4', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR5', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR6', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR8', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR10', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR14', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR18', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR22', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR26', ...
    %         'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR30', ...
    % 
    %         };
    foldersTrain = { 
            'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR10', ...
            'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE2_CR30'
            };

    maxEpochs = 20;
    checkpointDir = 'DataCalculated/Checkpoints_CRRun_NE2_LR1e-4';
    mkdir( checkpointDir );
    for cntFolder = 1 : length( foldersTrain )
    
        folderTrain = foldersTrain{ cntFolder };
        percentageTrain = 0.97;
    
        [~,nameOfRun,~] = fileparts(folderTrain);
        
        fprintf( '%s: Starting run %d of %d: %s\n', datestr(now), cntFolder, length( foldersTrain ), nameOfRun );
        load( strcat( folderTrain, '\settingsDataPreprocessing.mat' ) )
    
        audioDataStore = fileDatastore( strcat( folderTrain, '/lung*.mat' ), "ReadFcn", @readFileDataStore );
        [idxTrain, idxVal, idxTest ] = dividerand( size(audioDataStore.Files,1), percentageTrain, 1-percentageTrain, 0);
        audioDataStoreTrain = fileDatastore( audioDataStore.Files(idxTrain), "ReadFcn", @readFileDataStore );
        audioDataStoreValid = fileDatastore( audioDataStore.Files(idxVal), "ReadFcn", @readFileDataStore );
    
        numEmbeddings = settingsDataPreprocessing.numCompressionEmbeddings;
        inputSize = settingsDataPreprocessing.inputSizeAudioData;
    
        generateLungSoundUncompressionNetwork  
        
        trainingoptsFull = trainingOptions('adam', ...
                                'MaxEpochs', maxEpochs, ...
                                'MiniBatchSize',10, ...
                                'InitialLearnRate', 5e-5, ...
                                'LearnRateSchedule','piecewise', ...
                                'LearnRateDropPeriod', 1, ...
                                'LearnRateDropFactor', 0.97, ...
                                'Plots', 'training-progress', ...
                                'OutputNetwork', 'best-validation', ...
                                'Shuffle', 'every-epoch', ...
                                'ValidationFrequency',200, ...
                                'ValidationPatience', inf, ...
                                'InputDataFormats', {'SSCB'}) ;
        
        trainingoptsFull.ValidationData = audioDataStoreValid;
        
        trainingoptsFull.CheckpointFrequencyUnit = 'epoch';
        trainingoptsFull.CheckpointFrequency = 1;
        trainingoptsFull.CheckpointPath= checkpointDir;

        % Shuffle the training datastore
        audioDataStoreTrain = shuffle( audioDataStoreTrain );
        
      
        % Train the network
        netTrained =  trainnet( audioDataStoreTrain, netConvolutionalUncompressor , @(Y,T)customLungSoundLoss(Y, T), trainingoptsFull );
        
        structTrained = struct();
        structTrained.settingsDataPreprocessing = settingsDataPreprocessing;
        structTrained.netTrained = netTrained;
        structTrained.trainingoptsFull = trainingoptsFull;
    
        % [neNumber, crNumber] = extractNumbersFromPath(folderTrain);
        neNumber = settingsDataPreprocessing.numCompressionEmbeddings;
        crNumber = settingsDataPreprocessing.compressionFactorReal;

        fnSave = strcat( 'DataCalculated/LSU_NE', num2str(neNumber), '_CR', num2str(crNumber), '_', datestr( now, 'YYYYmmDD_HHMMSS' ), '.mat' );
        save( fnSave, 'structTrained' )

    end
   
    