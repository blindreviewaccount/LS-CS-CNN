net = dlnetwork;
    
    tempNet = [
    imageInputLayer([inputSize numEmbeddings 1],"Name","imageinput")
    convolution2dLayer([100 numEmbeddings],32,"Name","conv","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    batchNormalizationLayer("Name","batchnorm")
    averagePooling2dLayer([10 numEmbeddings],"Name","avgpool2d","Padding","same","Stride",[2 1])
    convolution2dLayer([100 numEmbeddings],32,"Name","conv_1","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_1")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    batchNormalizationLayer("Name","batchnorm_1")
    averagePooling2dLayer([10 numEmbeddings],"Name","avgpool2d_1","Padding","same","Stride",[2 1])
    convolution2dLayer([100 numEmbeddings],32,"Name","conv_2","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_2")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    batchNormalizationLayer("Name","batchnorm_2")
    averagePooling2dLayer([10 numEmbeddings],"Name","avgpool2d_2","Padding","same","Stride",[2 1])
    convolution2dLayer([100 numEmbeddings],32,"Name","conv_3","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_3")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    batchNormalizationLayer("Name","batchnorm_3")
    averagePooling2dLayer([10 numEmbeddings],"Name","avgpool2d_3","Padding","same","Stride",[2 1])
    convolution2dLayer([100 numEmbeddings],32,"Name","conv_4","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_4")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    batchNormalizationLayer("Name","batchnorm_4")
    averagePooling2dLayer([10 numEmbeddings],"Name","avgpool2d_4","Padding","same","Stride",[2 1])
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_5")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    depthConcatenationLayer(2,"Name","depthcat")
    batchNormalizationLayer("Name","batchnorm_5")
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv_1","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_6")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    depthConcatenationLayer(2,"Name","depthcat_1")
    batchNormalizationLayer("Name","batchnorm_6")
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv_2","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_7")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    depthConcatenationLayer(2,"Name","depthcat_2")
    batchNormalizationLayer("Name","batchnorm_7")
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv_3","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_8")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    depthConcatenationLayer(2,"Name","depthcat_3")
    batchNormalizationLayer("Name","batchnorm_8")
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv_4","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_9")];
    net = addLayers(net,tempNet);
    
    tempNet = [
    depthConcatenationLayer(2,"Name","depthcat_4")
    batchNormalizationLayer("Name","batchnorm_9")
    convolution2dLayer([100 numEmbeddings],16,"Name","conv_5","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_10")
    batchNormalizationLayer("Name","batchnorm_10")
    convolution2dLayer([100 numEmbeddings],1,"Name","conv_6","Padding","same")
    leakyReluLayer(0.01,"Name","leakyrelu_11")
    batchNormalizationLayer("Name","batchnorm_11")
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv_5","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_11_1")
    batchNormalizationLayer("Name","batchnorm_11_2")
    transposedConv2dLayer([100 numEmbeddings],32,"Name","transposed-conv_6","Cropping","same","Stride",[2 1])
    leakyReluLayer(0.01,"Name","leakyrelu_11_2")
    batchNormalizationLayer("Name","batchnorm_11_1")    
    averagePooling2dLayer([1 numEmbeddings],"Name","avgpool2d_5","Padding","same","Stride",[1 15])
    convolution2dLayer([100 1],1,"Name","conv_7","Padding","same")];
    net = addLayers(net,tempNet);
    
    % clean up helper variable
    clear tempNet;
    
    net = connectLayers(net,"leakyrelu","batchnorm");
    net = connectLayers(net,"leakyrelu","depthcat_4/in2");
    net = connectLayers(net,"leakyrelu_1","batchnorm_1");
    net = connectLayers(net,"leakyrelu_1","depthcat_3/in2");
    net = connectLayers(net,"leakyrelu_2","batchnorm_2");
    net = connectLayers(net,"leakyrelu_2","depthcat_2/in2");
    net = connectLayers(net,"leakyrelu_3","batchnorm_3");
    net = connectLayers(net,"leakyrelu_3","depthcat_1/in2");
    net = connectLayers(net,"leakyrelu_4","batchnorm_4");
    net = connectLayers(net,"leakyrelu_4","depthcat/in2");
    net = connectLayers(net,"leakyrelu_5","depthcat/in1");
    net = connectLayers(net,"leakyrelu_6","depthcat_1/in1");
    net = connectLayers(net,"leakyrelu_7","depthcat_2/in1");
    net = connectLayers(net,"leakyrelu_8","depthcat_3/in1");
    net = connectLayers(net,"leakyrelu_9","depthcat_4/in1");
    netConvolutionalUncompressor = initialize(net);