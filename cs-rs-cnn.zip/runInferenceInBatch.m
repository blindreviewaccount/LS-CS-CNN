


 folderData = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Source Data\test_compression_wav';
    % folderData = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\test_compression_wav';
    
    
    filesTest = dir( strcat( folderData, '/*.wav' ) );
    numAudioFilesTest = length( filesTest );
    
% 
% listToProcess = { 
%                     'LSU_NE1_CR5_20240504_114642', ...
%                     'LSU_NE2_CR5_20240503_175246', ...
%                     'LSU_NE3_CR5_20240503_200649', ...
%                     'LSU_NE4_CR5_20240504_002245', ...
%                     'LSU_NE5_CR5_20240504_161622'
%                     };

% listToProcess = { 
%                     'LSU_NE5_CR2_20240504_054038', ...
%                     'LSU_NE5_CR4_20240504_105922', ...
%                     'LSU_NE5_CR5_20240504_161622', ...
%                     'LSU_NE5_CR8_20240504_213652', ...
%                     'LSU_NE5_CR10_20240505_025612', ...
%                     'LSU_NE5_CR15_20240505_081827', ...
%                     'LSU_NE5_CR25_20240505_163841'
%                     };
% listToProcess = { 
%                     'LSU_NE5_CR2_20240504_054038', ...
%                     'LSU_NE5_CR4_20240504_105922', ...
%                     'LSU_NE5_CR5_20240504_161622', ...
%                     'LSU_NE5_CR8_20240504_213652', ...
%                     'LSU_NE5_CR10_20240505_025612', ...
%                     'LSU_NE5_CR15_20240505_081827', ...
%                     'LSU_NE5_CR25_20240505_163841'
%                     };
% listToProcess = { 
%                     'LSU_NE2_CR2_20240506_145502', ...
%                     'LSU_NE2_CR4_20240506_164210', ...
%                     'LSU_NE2_CR5_20240506_182608', ...
%                     'LSU_NE2_CR6_20240506_201108', ...
%                     'LSU_NE2_CR8_20240506_215533', ...
%                     'LSU_NE2_CR10_20240506_233954', ...
%                     'LSU_NE2_CR14_20240507_012415', ...
%                     'LSU_NE2_CR18_20240507_030841', ...
%                     'LSU_NE2_CR22_20240507_045322', ...
%                     'LSU_NE2_CR26_20240507_063757', ...
%                     'LSU_NE2_CR30_20240507_082347'
% 
%                     };
% folderToProcess = 'DataCalculated/Run_CR_NE2/';

listToProcess = { 
                    'LSU_NE2_CR10_20240508_004108', ...
                    'LSU_NE2_CR30_20240508_092151', ...
                    };

folderToProcess = 'DataCalculated/Final_Models/';

numModelsToInference = length( listToProcess );

load( strcat( folderToProcess, '/', listToProcess{1 } ) )


vecNE = zeros( numModelsToInference, 1 );
vecCR = zeros( numModelsToInference, 1 );


allDataPredict = nan( structTrained.settingsDataPreprocessing.OutputSizeAudioData, numAudioFilesTest, numModelsToInference );
allDataCorrect = nan( structTrained.settingsDataPreprocessing.OutputSizeAudioData, numAudioFilesTest, numModelsToInference );
PB = ProgressBar( numAudioFilesTest*numModelsToInference, 'Processing the test data', 'cli' );

for cntInference = 1 : numModelsToInference
    load( strcat( folderToProcess, '/', listToProcess{cntInference } ) )

    vecNE( cntInference ) = structTrained.settingsDataPreprocessing.numCompressionEmbeddings;
    vecCR( cntInference ) = structTrained.settingsDataPreprocessing.compressionFactorReal;

    for cntFile = 1 : numAudioFilesTest
        
        fileToRead = filesTest( cntFile );
        filenameAudio = strcat( fileToRead.folder, '/', fileToRead.name );    
       
        [ sigCompressed, sigCorrect, lengthNoZeropad, orignalSignalAmplitude ] = preprocessSingleMeasurement( filenameAudio, structTrained.settingsDataPreprocessing );
        
        sigPredict = predict( structTrained.netTrained, gpuArray(sigCompressed) );

        allDataPredict( 1:lengthNoZeropad, cntFile, cntInference ) = sigPredict(1:lengthNoZeropad);
        allDataCorrect( 1:lengthNoZeropad, cntFile, cntInference ) = sigCorrect(1:lengthNoZeropad);
        
        count( PB )
    end

end


%% Now calculate metrics:

matPRD = zeros( numAudioFilesTest, numModelsToInference );
matCC = zeros( numAudioFilesTest, numModelsToInference );

PB = ProgressBar( numAudioFilesTest*numModelsToInference, 'Calculating Metrics:', 'cli' );


for cntInference = 1 : numModelsToInference
    for cntFile = 1 : numAudioFilesTest
        curPredict = allDataPredict(:, cntFile, cntInference );
        curCorrect = allDataCorrect( :, cntFile, cntInference ) ;

        idxNotNAN = find( ( ~isnan(curPredict) ) & ( ~isnan(curCorrect) ) );
        PRD = sqrt( sum( ( curPredict(idxNotNAN) - curCorrect(idxNotNAN) ).^2 ) / sum( curCorrect(idxNotNAN).^2 ) );
        corrCoeffMat = corrcoef( curPredict(idxNotNAN), curCorrect(idxNotNAN) );


        matPRD( cntFile, cntInference ) = PRD;
        matCC( cntFile, cntInference ) = corrCoeffMat( 1, 2 ) ;
        count( PB )
    end
end

vecScore = zeros( numAudioFilesTest, length( vecCR ) );

for cntSignal = 1 : length( vecCR )

    curScore = vecCR(cntSignal )./ (2 - matCC(:, cntSignal ) + matPRD( :, cntSignal ) );
    vecScore( :, cntSignal ) = curScore;
end

meanPRD = mean( matPRD );
medianPRD = median( matPRD );
stdPRD = std( matPRD, [], 1 );
meanCC = mean( matCC );
medianCC = median( matCC );
stdCC = std( matCC, [], 1 );

% figure; 
%     errorbar( vecNE, meanPRD, stdPRD, 'linewidth', 1.5 )
%     hold on;
%     errorbar( vecNE, meanCC, stdCC, 'linewidth', 1.5 )
%     grid on
%     legend( 'PRD', 'CC' );
%     xlabel( 'Number of Embeddings' )
%     ylabel( 'Value' );
%     xlim( [ 0  5.5 ] )
%     title( 'Number of Embeddings vs Competition Metrics' )

figure; 
    errorbar( vecCR, meanPRD, stdPRD, 'linewidth', 1.5 )
    hold on;
    errorbar( vecCR, meanCC, stdCC, 'linewidth', 1.5 )
    grid on
    legend( 'PRD', 'CC' );
    xlabel( 'CR' )
    ylabel( 'Value' );
    xlim( [8 32 ] )
    title( 'CR vs Competition Metrics' )


meanScore = mean( vecScore, 1 );
stdScore = std( vecScore, [], 1 );
figure; 
    errorbar( vecCR, meanScore, stdScore, 'linewidth', 1.5 )
    grid on
    legend( 'Competition Score' );
    xlabel( 'Compression Ratio' )
    ylabel( 'Value' );
    xlim( [ 8  32 ] )
    title( 'Compression Ratio vs Competition Metrics' )

