

 folderData = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Source Data\test_compression_wav';
    % folderData = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\test_compression_wav';
    
    
    filesTest = dir( strcat( folderData, '/*.wav' ) );
    numAudioFilesTest = length( filesTest );
    
% 
% listToProcess = { 
%                     'LSU_NE1_CR5_20240504_114642', ...
%                     'LSU_NE2_CR5_20240503_175246', ...
%                     'LSU_NE3_CR5_20240503_200649', ...
%                     'LSU_NE4_CR5_20240504_002245', ...
%                     'LSU_NE5_CR5_20240504_161622'
%                     };
% 
% listToProcess = { 
%                     'LSU_NE5_CR2_20240504_054038', ...
%                     'LSU_NE5_CR4_20240504_105922', ...
%                     'LSU_NE5_CR5_20240504_161622', ...
%                     'LSU_NE5_CR8_20240504_213652', ...
%                     'LSU_NE5_CR10_20240505_025612', ...
%                     'LSU_NE5_CR15_20240505_081827', ...
%                     };
% listToProcess = { 
%                     'net_checkpoint__2758__2024_05_05__16_26_38', ...
%                     'net_checkpoint__5516__2024_05_05__16_52_37', ...
%                     'net_checkpoint__8274__2024_05_05__17_18_36', ...
%                     'net_checkpoint__11032__2024_05_05__17_44_37', ...
%                     'net_checkpoint__13790__2024_05_05__18_10_19',...
%                     'net_checkpoint__16548__2024_05_05__18_37_03',...
%                     'net_checkpoint__19306__2024_05_05__19_03_05',...
%                     'net_checkpoint__22064__2024_05_05__19_29_41',...
%                     'net_checkpoint__24822__2024_05_05__19_55_49',...
%                     'net_checkpoint__27580__2024_05_05__20_21_32'
%                     };
% load( strcat( 'DataCalculated\Checkpoints_EpochRun_LR1e-5\', 'LSU_NE2_CR5_20240505_202132.mat' ) )
listToProcess = { 
                    'net_checkpoint__2758__2024_05_05__20_52_51', ...
                    'net_checkpoint__5516__2024_05_05__21_18_28', ...
                    'net_checkpoint__8274__2024_05_05__21_44_06', ...
                    'net_checkpoint__11032__2024_05_05__22_09_44', ...
                    'net_checkpoint__13790__2024_05_05__22_35_06',...
                    'net_checkpoint__16548__2024_05_05__23_00_46',...
                    'net_checkpoint__19306__2024_05_05__23_26_25',...
                    'net_checkpoint__22064__2024_05_05__23_52_05',...
                    'net_checkpoint__24822__2024_05_06__00_17_44',...
                    'net_checkpoint__27580__2024_05_06__00_43_24'
                    };
load( strcat( 'DataCalculated\Checkpoints_EpochRun_LR1e-4\', 'LSU_NE2_CR5_20240506_004324.mat' ) )

numModelsToInference = length( listToProcess );


% matPRD = zeros( numAudioFilesTest, numModelsToInference );
% matCC = zeros( numAudioFilesTest, numModelsToInference );

vecNE = zeros( numModelsToInference, 1 );
vecCR = zeros( numModelsToInference, 1 );
% vecEpochs = zeros( numModelsToInference, 1 );


allDataPredict = nan( structTrained.settingsDataPreprocessing.OutputSizeAudioData, numAudioFilesTest, numModelsToInference );
allDataCorrect = nan( structTrained.settingsDataPreprocessing.OutputSizeAudioData, numAudioFilesTest, numModelsToInference );
PB = ProgressBar( numAudioFilesTest*numModelsToInference, 'Processing the test data', 'cli' );

for cntInference = 1 : numModelsToInference
    load( strcat( 'DataCalculated\Checkpoints_EpochRun_LR1e-4\', listToProcess{cntInference } ) )
    structTrained.netTrained = net;
    % vecNE( cntInference ) = structTrained.settingsDataPreprocessing.numCompressionEmbeddings;
    % vecCR( cntInference ) = structTrained.settingsDataPreprocessing.compressionFactorReal;
    
    for cntFile = 1 : numAudioFilesTest
        
        fileToRead = filesTest( cntFile );
        filenameAudio = strcat( fileToRead.folder, '/', fileToRead.name );    
       
        [ sigCompressed, sigCorrect, lengthNoZeropad ] = preprocessSingleMeasurement( filenameAudio, structTrained.settingsDataPreprocessing );
        
        sigPredict = predict( structTrained.netTrained, gpuArray(sigCompressed) );

        allDataPredict( 1:lengthNoZeropad, cntFile, cntInference ) = sigPredict(1:lengthNoZeropad);
        allDataCorrect( 1:lengthNoZeropad, cntFile, cntInference ) = sigCorrect(1:lengthNoZeropad);
        
        count( PB )
    end

end


%% Now calculate metrics:

matPRD = zeros( numAudioFilesTest, numModelsToInference );
matCC = zeros( numAudioFilesTest, numModelsToInference );

PB = ProgressBar( numAudioFilesTest*numModelsToInference, 'Calculating Metrics:', 'cli' );


for cntInference = 1 : numModelsToInference
    for cntFile = 1 : numAudioFilesTest
        curPredict = allDataPredict(:, cntFile, cntInference );
        curCorrect = allDataCorrect( :, cntFile, cntInference ) ;

        idxNotNAN = find( ( ~isnan(curPredict) ) & ( ~isnan(curCorrect) ) );
        PRD = sqrt( sum( ( curPredict(idxNotNAN) - curCorrect(idxNotNAN) ).^2 ) / sum( curCorrect(idxNotNAN).^2 ) );
        corrCoeffMat = corrcoef( curPredict(idxNotNAN), curCorrect(idxNotNAN) );

        matPRD( cntFile, cntInference ) = PRD;
        matCC( cntFile, cntInference ) = corrCoeffMat( 1, 2 ) ;
        count( PB )
    end
end



meanPRD = mean( matPRD );
medianPRD = median( matPRD );
stdPRD = std( matPRD, [], 1 );
meanCC = mean( matCC );
medianCC = median( matCC );
stdCC = std( matCC, [], 1 );

figure; 
    errorbar( meanPRD, stdPRD, 'linewidth', 1.5 )
    hold on;
    errorbar( meanCC, stdCC, 'linewidth', 1.5 )
    grid on
    legend( 'PRD', 'CC' );
    xlabel( 'Training Epochs' )
    ylabel( 'Value' );
    xlim( [ 0  11 ] )
    title( 'Training Epoch vs Competition Metrics' )

