 
    close all
    clear
    clc

    close(findall(groot, "Type", "figure"));
    path(pathdef);
    addpath( genpath( 'Source' ) )    



%%  Make the datastores

    % folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed_Using_RandomSampling';
    % folderTrain = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Preprocessed Data\Preprocessed_RS_NE10_CR5';
    folderTrain = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\Preprocessed Data\Preprocessed_TF_NE5_CR10';


    percentageTrain = 0.97;

    load( strcat( folderTrain, '\settingsDataPreprocessing.mat' ) )

    audioDataStore = fileDatastore( strcat( folderTrain, '/lung*.mat' ), "ReadFcn", @readFileDataStoreTF );
    [idxTrain, idxVal, idxTest ] = dividerand( size(audioDataStore.Files,1), percentageTrain, 1-percentageTrain, 0);
    audioDataStoreTrain = fileDatastore( audioDataStore.Files(idxTrain), "ReadFcn", @readFileDataStoreTF );
    audioDataStoreValid = fileDatastore( audioDataStore.Files(idxVal), "ReadFcn", @readFileDataStoreTF );

%% General settings of the network:
    numEmbeddings = settingsDataPreprocessing.numCompressionEmbeddings;
    inputSize = settingsDataPreprocessing.numTimeSamplesInSingleCompression;
    
    % inputSize = 9600;

    numRandomSamplesAfterUncompression = 36000;
    signalOutputSize = settingsDataPreprocessing.OutputSizeAudioData;

    numFourierComponents = 3;
    numOutputSequencesDecompressor = 2;

%% Generate the network:

    net = dlnetwork;
    tempNet = inputLayer([inputSize numEmbeddings 1],"SCB","Name","inputData");
    net = addLayers(net,tempNet);
    
    tempNet = inputLayer([inputSize numEmbeddings 1],"SCB","Name","inputTimestamps");
    net = addLayers(net,tempNet);
    
    tempNet = [
        SignalUncompressionLayer( 'RandomUncompressor', numEmbeddings, numOutputSequencesDecompressor, inputSize, numFourierComponents, numRandomSamplesAfterUncompression, 300 );

        convolution1dLayer(100,32,"Name","conv1d","Padding","same")
        leakyReluLayer(0.01,"Name","leakyrelu")
        batchNormalizationLayer("Name","batchnorm")
        transposedConv1dLayer(100,32,"Name","transposed-conv1d","Cropping","same","Stride",2)
        leakyReluLayer(0.01,"Name","leakyrelu_1")
        batchNormalizationLayer("Name","batchnorm_1")
        transposedConv1dLayer(100,32,"Name","transposed-conv1d_1","Cropping","same","Stride",2)
        leakyReluLayer(0.01,"Name","leakyrelu_2")
        batchNormalizationLayer("Name","batchnorm_2")
        convolution1dLayer(100,5,"Name","conv1d_1","Padding","same")
        leakyReluLayer(0.01,"Name","leakyrelu_3")
        batchNormalizationLayer("Name","batchnorm_3")
        convolution1dLayer(100,1,"Name","conv1d_2","Padding","same")
        leakyReluLayer(0.01,"Name","leakyrelu_4")
        batchNormalizationLayer("Name","batchnorm_4")
        resize2dLayer("Name","resize-output-size","GeometricTransformMode","half-pixel","Method","nearest","NearestRoundingMode","round","OutputSize",[signalOutputSize 1])];
    net = addLayers(net,tempNet);
    
    % clean up helper variable
    clear tempNet;
    
    net = connectLayers(net,"inputData","RandomUncompressor/in1");
    net = connectLayers(net,"inputTimestamps","RandomUncompressor/in2");
    netTransformerUncompressor = initialize(net);
%% Now, do a test run:

 trainingoptsFull = trainingOptions('adam', ...
                            'MaxEpochs', 3, ...
                            'MiniBatchSize',5, ...
                            'InitialLearnRate', 1e-4, ...
                            'LearnRateSchedule','none', ...
                            'LearnRateDropPeriod', 2, ...
                            'LearnRateDropFactor', 0.98, ...
                            'Plots', 'training-progress', ...
                            'OutputNetwork', 'best-validation', ...
                            'Shuffle', 'every-epoch', ...
                            'ValidationFrequency',200, ...
                            'ValidationPatience', inf, ...
                            'InputDataFormats', {'SCB', 'SCB'}) ;
    
    trainingoptsFull.ValidationData = audioDataStoreValid;
    
    % Shuffle the training datastore
    audioDataStoreTrain = shuffle( audioDataStoreTrain );
    
    % Train the network
    netTrained =  trainnet( audioDataStoreTrain, netTransformerUncompressor , @(Y,T)customLungSoundLoss(Y, T), trainingoptsFull );
    
    structTrained = struct();
    structTrained.settingsDataPreprocessing = settingsDataPreprocessing;
    structTrained.netTrained = netTrained;
    structTrained.trainingoptsFull = trainingoptsFull;


    sampleTest = read( audioDataStoreTrain );

    dataPredict = double( predict( netTrained, sampleTest{1}, sampleTest{2}  ) );




    [neNumber, crNumber] = extractNumbersFromPath(folderTrain);


    fnSave = strcat( 'DataCalculated/LSU_TF_NE', num2str(neNumber), '_CR', num2str(crNumber), '_', datestr( now, 'YYYYmmDD_HHMMSS' ), '.mat' );
    save( fnSave, 'structTrained' )
