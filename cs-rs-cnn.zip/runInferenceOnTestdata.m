%% Init:

    % close all
    % clear
    % clc

    % close(findall(groot, "Type", "figure"));
    path(pathdef);
    addpath( genpath( 'Source' ) )    

%% Find some files:

    % load( 'DataCalculated\LSU_NE2_CR5_20240503_175246' )
    % load( 'DataCalculated\LSU_NE3_CR5_20240503_200649' )
    load( 'DataCalculated\LSU_NE4_CR5_20240504_002245' )
    % load( 'DataCalculated\LSU_NE3_CR5_20240503_200649' )
    % load( 'DataCalculated\LSU_NE3_CR5_20240503_200649' )

    % folderData = 'D:\Deep Learning Data\20240430 - Lung Sound Challenge\Source Data\test_compression_wav';
    folderData = 'E:\Data Deeplearning\20240502 - Lung Sound Competition\test_compression_wav';
    
    
    filesTest = dir( strcat( folderData, '/*.wav' ) );
    numAudioFilesTest = length( filesTest );
    
    allDataPredict = zeros( structTrained.settingsDataPreprocessing.OutputSizeAudioData, numAudioFilesTest );
    allDataCorrect = zeros( structTrained.settingsDataPreprocessing.OutputSizeAudioData, numAudioFilesTest );

    PB = ProgressBar( numAudioFilesTest, 'Processing the test data', 'cli' );

    for cntFile = 1 : numAudioFilesTest
        
        fileToRead = filesTest( cntFile );
        filenameAudio = strcat( fileToRead.folder, '/', fileToRead.name );    
       
        [ sigCompressed, sigCorrect ] = preprocessSingleMeasurement( filenameAudio, structTrained.settingsDataPreprocessing );
        
        sigPredict = predict( structTrained.netTrained, gpuArray(sigCompressed) );

        allDataPredict( :, cntFile ) = sigPredict;
        allDataCorrect( :, cntFile ) = sigCorrect;
        
        count( PB )
    end

    %% Now, calculate the metrix from the competition

    CR = structTrained.settingsDataPreprocessing.compressionFactorReal;
    NE = structTrained.settingsDataPreprocessing.numCompressionEmbeddings;
    CTS = structTrained.settingsDataPreprocessing.numTimeSamplesInSingleCompression;

    vecCC = nan( numAudioFilesTest, 1 );
    vecPRD = nan( numAudioFilesTest, 1 );

    for cntFile = 1 : numAudioFilesTest
        curPredict = allDataPredict(:, cntFile );
        curCorrect = allDataCorrect( :, cntFile );

        PRD = sqrt( sum( ( curPredict(:) - curCorrect(:) ).^2 ) / sum( curCorrect(:).^2 ) );
        corrCoeffMat = corrcoef( curPredict, curCorrect );

        vecCC( cntFile ) = corrCoeffMat( 1, 2 ) ;
        vecPRD( cntFile ) = PRD;
    end





    figure; 
        set( gcf, 'position', [372         664        1527         574]);
        subplot( 1,2,1); 
            hist( vecPRD, 100 );
            xlabel( 'PRD' )
            ylabel( 'Occurence' )
            title( 'PRD Histogram' )
            grid on
            xlim( [ 0 1.2] )
            hold on;
        subplot( 1,2,2); 
            hist( vecCC, 100 )
            xlabel( 'CC' )
            ylabel( 'Occurence' )
            title( 'CC Histogram' )            
            grid on;
            xlim( [ 0 1.2] )

        sgtitle( sprintf( 'Competition Metrics, CR: %d, CTS: %d, NE: %d', CR, CTS, NE ) )


